# nprobe-udm
Ntop nProbe deployment on Ubiquiti UDM-Pro inside a podman container

View docker_build.sh for notes on what to do.
